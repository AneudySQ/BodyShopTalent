// Redirect
function delayedRedirect()	{
    window.location = 'https://bodyshoptalent.com/'
}

