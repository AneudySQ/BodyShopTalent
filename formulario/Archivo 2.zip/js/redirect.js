// Redirect
function delayedRedirect()	{
    window.location = 'https://ultimatewebsolutions.net/sendy/'
}

